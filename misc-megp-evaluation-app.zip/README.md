# MISC Executive Graduate Programme (MEGP) Level 1 Evaluation & Dashboard

A complete, self-contained web application combining:
1. **Participant Evaluation Survey (Level 1 Feedback)**
2. **Executive Analytics Dashboard (Real-time charts, KPIs, qualitative feedback)**
3. **Google Forms & Google Sheets Backend Integration**

---

## 🚀 How to Run the App

Open [`index.html`](file:///C:/Users/junai/.gemini/antigravity/scratch/misc-onboarding-eval/index.html) directly in any web browser:
- You can double-click `index.html` or run:
```powershell
Start-Process "C:\Users\junai\.gemini\antigravity\scratch\misc-onboarding-eval\index.html"
```

---

## 📊 Features Included

### 1. Facilitator-Only Access Control (Security Gate)
- **Protected Access:** The **Analytics Dashboard** is locked specifically for programme facilitators and administrators.
- **Passcode:** `misc2026` (can be changed in the script).
- Participants completing the evaluation can submit their feedback and see their own personal summary, but cannot access aggregated cohort scores, qualitative remarks, or respondent identities without the facilitator passcode.
- Includes quick **"Log Out"** button to re-lock the dashboard.

### 2. Print & PDF Export for Executive Presentation
- Dedicated **"🖨️ Print / Save as PDF"** button directly on the dashboard.
- Custom `@media print` styling:
  - Cleans up navigation buttons, tabs, interactive elements, and forms.
  - Automatically formats charts, KPI metrics, and qualitative tables into an executive-ready portrait/landscape report.
  - Includes formal MISC MEGP evaluation header with timestamp and confidentiality notices.

### 3. Participant Evaluation Form
- **Demographics:** Participant Name, Email, and Business/Function dropdown (Gas Assets & Solutions, Petroleum & Product Shipping, Offshore Business, Marine & Heavy Engineering, New Energy & Decarbonisation, Marine Services, Maritime Education & Training, Corporate Functions, Other).
- **Sections 1 to 3 (Likert 1–5 Scale):**
  - Section 1: Overall Programme Experience (7 questions)
  - Section 2: Experience Across the Five Days (5 questions)
  - Section 3: Facilitators & Speakers (4 questions)
- **Section 4 (Qualitative & Day 4 Highlights):**
  - Day 4 Most Valued Activity (The Voyage Challenge, MISC Innovation Sprint, The Leadership Mission, Tale of Two Towers, Back to the Future, Other).
  - Open-ended reflections (Most valuable experience, what to continue, what to improve).
- **Immediate Individual Scoring:** Computes individual Section 1, 2, 3 and Overall scores upon submission.

### 2. Executive Analytics Dashboard
- **Executive KPIs:** Total submissions, average cohort rating (/5.00), high satisfaction percentage, Net Promoter Sentiment.
- **Visual Analytics (Chart.js):**
  - **Section Score Benchmarks:** Bar chart comparing Sections 1, 2, and 3.
  - **Day 1–5 Progression Journey:** Interactive line chart tracking satisfaction across the 5 days.
  - **Day 4 Activity Impact:** Donut chart breakdown of top-voted experiential activities.
  - **Business Unit Distribution:** Polar chart showing participation across MISC businesses.
- **Responses Data Table:** Full listing with qualitative feedback and CSV Export button.

---

## 🔗 Linking with Google Forms & Google Sheets

### Method A: Automated Submissions to Google Sheets via Webhook (Recommended)
1. Open [Google Sheets](https://sheets.new) and name the spreadsheet `MISC_MEGP_Evaluation_L1`.
2. Go to **Extensions &rarr; Apps Script**.
3. Replace the code in the editor with:
```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = JSON.parse(e.postData.contents);
  sheet.appendRow([
    new Date(),
    data.name,
    data.email,
    data.function,
    data.overallScore,
    data.s1Score,
    data.s2Score,
    data.s3Score,
    data.q17,
    data.q18,
    data.q19,
    data.q20
  ]);
  return ContentService.createTextOutput(JSON.stringify({result: 'success'}))
    .setMimeType(ContentService.MimeType.JSON);
}
```
4. Click **Deploy &rarr; New Deployment &rarr; Web app**.
   - Under **Who has access**, select **Anyone**.
   - Copy the generated Web App URL.
5. In the app header, click **🔗 Google Form Integration**, paste the Web App URL, and click **Save URL**.
6. Every evaluation submitted in the app will now automatically sync to your Google Sheet in real time!

### Method B: Native Google Form Linking
- If you have an existing Google Form, click **🔗 Google Form Integration** in the app to embed or hyperlink your Google Form URL directly.
